import SwiftUI

@main
struct CoffeeCounterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
